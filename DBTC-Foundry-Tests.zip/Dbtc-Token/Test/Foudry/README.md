markdown

# DBTC Foundry Tests

This folder contains all Foundry tests executed on the **DeflationaryBTC (DBTC)** smart contract.

## 📅 Test Date
Tests were performed on **September 20, 2025**.

## 🧪 Test Summary
All 10 tests executed successfully:

- `testAllowanceTransferFrom()` ✅  
- `testBurnFunction()` ✅  
- `testClaimRewards()` ✅  
- `testDOSLockPagination()` ✅  
- `testInitialMint()` ✅  
- `testReentrancyGuard()` ✅  
- `testStake12Months()` ✅  
- `testStake6Months()` ✅  
- `testStakeNormal()` ✅  
- `testTransferFee()` ✅  

**All tests passed with 0 failures.**

## ⚡ Initial Mint
The test `testInitialMint()` now reflects the **real initial supply** of `2,000,000,000 DBTC` (18 decimals), fully consistent with the deployed contract.

## 🔧 Running the Tests
1. Install Foundry:
   ```bash
   curl -L https://foundry.paradigm.xyz | bash
   foundryup

    Run all tests:

forge test

Check coverage:

    forge coverage

📄 Folder Structure

Foundry/
├── DeflationaryBTCTest.t.sol      # Solidity test contract
├── TestResults_2025-09-20.pdf     # PDF of test results
└── README.md                      # This file

✅ Notes

    Tests use the actual initial mint for full consistency with production contract.

    Only essential files are included to keep the repo clean and professional.

    The PDF contains gas usage, function call statistics, and test suite results for reference.

yaml